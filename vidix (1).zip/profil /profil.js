document.addEventListener('DOMContentLoaded', function() {
    // Ambil elemen-elemen tombol
    const logoutBtn = document.getElementById('logout-btn');
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const editProfileSection = document.getElementById('edit-profile-section');
    const editProfileForm = document.getElementById('edit-profile-form');
    
    // Cek apakah elemen ada sebelum menambahkan event listener
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            // Hapus data login dari localStorage
            localStorage.removeItem('loggedIn');
            // Redirect ke halaman login
            window.location.href = 'login.html';
        });
    }

    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', () => {
            // Toggle form edit profil
            editProfileSection.style.display = editProfileSection.style.display === 'none' ? 'block' : 'none';
        });
    }

    if (editProfileForm) {
        editProfileForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const newUsername = document.getElementById('new-username').value;
            const newEmail = document.getElementById('new-email').value;

            if (!newUsername || !newEmail) {
                return alert('Username dan Email harus diisi');
            }

            // Update data pengguna di localStorage
            const user = JSON.parse(localStorage.getItem('loggedIn'));
            user.username = newUsername;
            user.email = newEmail;
            localStorage.setItem('loggedIn', JSON.stringify(user));

            // Tampilkan informasi terbaru di halaman
            document.getElementById('username').textContent = 'Username: ' + newUsername;
            document.getElementById('email').textContent = 'Email: ' + newEmail;

            // Sembunyikan form setelah menyimpan perubahan
            editProfileSection.style.display = 'none';
        });
    }
});