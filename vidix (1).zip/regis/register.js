// register.js

document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (!username || !password) {
        return alert('Username dan Password harus diisi');
    }

    // Simpan data pengguna di localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    users.push({ username, password });
    localStorage.setItem('users', JSON.stringify(users));

    alert('Akun berhasil dibuat! Silakan login.');
    window.location.href = 'login.html'; // Arahkan ke halaman login setelah pendaftaran berhasil
});