document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validasi login (contoh data hardcoded)
    if (email === "user@vidix.com" && password === "password123") {
        alert("Login berhasil!");
        window.location.href = "../index.html";  // Redirect ke halaman utama (Feed atau Profil)
    } else {
        alert("Email atau password salah!");
    }
});