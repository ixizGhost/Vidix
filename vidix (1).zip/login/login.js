// Registrasi Pengguna
document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();

    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;

    if (!username || !email || !password || !confirmPassword) {
        return alert('Semua kolom harus diisi');
    }

    if (password !== confirmPassword) {
        return alert('Password dan Konfirmasi Password tidak cocok');
    }

    // Cek apakah username sudah ada
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.username === username);

    if (existingUser) {
        return alert('Username sudah terdaftar');
    }

    // Tambahkan pengguna baru ke localStorage
    const newUser = { username, email, password };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));

    alert('Registrasi berhasil! Silakan login.');
    window.location.href = 'login.html'; // Arahkan ke halaman login setelah registrasi berhasil
});

// Login Pengguna
document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    if (!username || !password) {
        return alert('Username dan Password harus diisi');
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        // Simpan status login di localStorage
        localStorage.setItem('loggedIn', JSON.stringify(user));
        alert('Login berhasil!');
        window.location.href = 'index.html'; // Arahkan ke halaman utama setelah login berhasil
    } else {
        alert('Username atau Password salah!');
    }
});